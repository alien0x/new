<?php 
//here we didnt use id for each member cause it depend on session to appear this page
    session_start();
    $pageTitle = 'reset';
    include 'init.php';
    include 'connect.php';
    if (isset($_SESSION['user'])){

        ?>
<style>
        body {
            font-family: Circular, "Helvetica Neue", Helvetica, Arial, sans-serif;
            font-size: 14px;
            line-height: 1.43;
            color: #484848;
            -webkit-font-smoothing: antialiased;
        }

        #forgot_div {
            margin: 10% 34%
        }

        @media only screen and (min-width: 769px) {
            #forgot_div {
                max-width: 32%;
            }
        }

        @media only screen and (max-width: 768px) {
            #forgot_div {
                max-width: 90%;
                min-width: 90%;
                margin: 0 5%;
            }
        }

        .mybtn {
            border-color: #ff5a5f !important;
            background-color: #ff5a5f !important;
            color: #fff !important;
            margin-bottom: 0;
            border-radius: 4px;
            border: 1px solid;
            text-align: center;
            vertical-align: middle;
            font-weight: bold;
            line-height: 1.43;
            user-select: none;
            padding: 9px 27px;
            font-size: 16px;
        }
        .panel-heading {
            color: #fff !important;
        }
    </style>
    
    <div class="container">
        <div id="forgot_div">
            <div class="panel panel-default">
                <div class="panel-heading"><strong>Reset Password</strong></div>
                <div class="panel-body">
                    <div class="panel-body">
                        <form id="resetform" autocomplete="off" method="post" action="">
                            <?php
                            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                                //collect all data from user
                                $session     = $_SESSION['user'];
                                $password1 = $_REQUEST['password1'];
                                $password2 = $_REQUEST['password2'];
                                if ($password1 == $password2) {
                                    $stm = $con->prepare('update users set Password = ? where Username = ?');
                                    $m = $stm->execute(array($password1, $session));
                                    if ($m) {
                                        echo 'updated succefully';
                                    } else {
                                        echo 'not updated';
                                    }
                                } else {
                                    echo 'not match';
                                }
                            }
                            ?>
                            <div class="form-group">
                                <input type="password" class="form-control" name="password1" id="passwordid" placeholder="New Password" required>
                            </div>
                            <div class="form-group">
                                <input id="password_two" required class="form-control" name="password2" type="password" placeholder="Confirm Password" required>
                            </div>
                            <div class="form-group">
                                <input class="btn btn-block btn-large mybtn" id="submit" name="reset-btn" value="Save &amp; Continue" type="submit">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php
   }else{
    header('location: login.php');
    exit();
}

include 'includes/templetes/footer.php'; ?>

