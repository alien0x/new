<?php 

include 'connect.php';

include 'includes/functions/functions.php';
include 'includes/templetes/header.php';


if(!isset($noNavbar)){
    include 'includes/templetes/navbar.php';
}



