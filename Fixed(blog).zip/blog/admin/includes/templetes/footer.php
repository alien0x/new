
        <div class="footer">
            
        </div>
        <script src="layout/js/jquery-3.5.1.min.js"></script>
        <script src="layout/js/bootstrap.min.js"></script>
        <script src="layout/js/style.js"></script>
        <script src="js/popper.min.js"></script>

    </body>
</html>
