<?php


    function lang($phrase){

        static $lang = array(
            
            //dashboard words

           /* '' => ''
            '' => ''
            '' => ''
            '' => ''
            '' => ''*/
        );
        return $lang[$phrase];
    }